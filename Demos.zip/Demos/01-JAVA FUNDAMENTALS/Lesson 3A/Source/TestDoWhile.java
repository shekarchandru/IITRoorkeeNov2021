class TestDoWhile
{
	public static void main(String args[])
	{
		int num = 100;
		 o
		{
			System.out.println("Inside the do-while loop");
		 	System.out.println("The value of variable num is:" + num); 
		}
		while(num<100);
	}
}
