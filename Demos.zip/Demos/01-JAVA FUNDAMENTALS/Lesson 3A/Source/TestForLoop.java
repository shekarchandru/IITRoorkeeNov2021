//TestForLoop.java
class TestForLoop
{
	public static void main(String args[])
	{� or(int i=1;i<6;i=i+1) // i is the initialization expression, which is checked to be less that 6. i=i+1 is the reinitialization expression.
		{
			System.out.println("The value of i is:" + i);
// The statement is executed till the condition is true
		}
	}
}
