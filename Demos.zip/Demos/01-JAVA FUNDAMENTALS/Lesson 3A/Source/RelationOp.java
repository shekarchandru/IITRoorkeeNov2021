//class declaration
class RelationOp 
{
	public static void main(String args[])
	{
		int 	 e;
		// Value assigned to the data member
		age =20;
		// The if construct
		if(age<10) 
		{
			System.out.println("The given age is below 10."); //if the condition is true this statement is executed.
		}
		else
		{ // if the condition is false, this construct is executed
    if(age>10)
		    {
			System.out.println("The given age is above 10.");
		    }
		}
	}
}
