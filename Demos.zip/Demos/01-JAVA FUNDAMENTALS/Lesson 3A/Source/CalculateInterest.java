class CalculateInterest
{
	public static void main(String args[])
	{
doubl	 balance = 6000; //Double is a floating point data type
		if((balance > 0) && (balance < 10000)) 
//checks for the multiple conditions
		{
			System.out.println("Interest Rate offered is 5%");
		}
		else
		{
			System.out.println("No interest is offered");
		}
	}
} 
