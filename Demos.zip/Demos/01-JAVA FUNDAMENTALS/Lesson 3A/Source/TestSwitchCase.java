class TestSwitchCase
{
	public static void main(String args[])
	{
		char X='d';
	� witch(X)
		{
			case 'a':
				System.out.println("The variable X is an alphabet and value is:" + X );
				break;
			case 'b':
				System.out.println("The variable X is an alphabet and value is:" + X );
				break;
			case 'c':
				System.out.println("The variable X is an alphabet and value is:" + X );
				break;
			case 'd':
				System.out.println("The variable X is an alphabet and value is:" + X );
				break;
		}
	}
}
