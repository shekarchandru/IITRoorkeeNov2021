class Hello
{
	public static void main(String args[])
	{
/* Output of the String */
System.out.println("W�come to the Exciting World of Java");		
	}
}
