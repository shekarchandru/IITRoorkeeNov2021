class BitWiseNOT
{
	public static void main(String arr[])
	{
		int x=2;
         	int a ;� 		a = ~x; // Bit-wise NOT operator
		System.out.println("The bit-wise NOT of 2 is: " +a) ;
	}
}
