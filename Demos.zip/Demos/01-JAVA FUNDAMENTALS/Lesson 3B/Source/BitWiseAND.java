class BitWiseOR
{
	public static void main(String arr[])
	{
		int x=2, y = 3;
         	i�  a ;
		a = x|y; // Bit-wise OR operator
		System.out.println("The bit-wise OR of 2 and 3 is: " +a) ;
	}
}
