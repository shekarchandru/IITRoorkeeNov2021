class BitWiseXOR
{
	public static void main(String arr[])
	{
		int x=2, y = 3;
         		 t a ;
		a = x^y; // Bit-wise XOR operator
		System.out.println("The bit-wise XOR of 2 and 3 is: " +a) ;
	}
}
