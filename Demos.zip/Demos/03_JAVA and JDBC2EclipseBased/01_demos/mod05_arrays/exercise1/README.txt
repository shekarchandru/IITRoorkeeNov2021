Overview
--------

The purpose of this demo is to show students how to declare, create and manipulate an one-dimension array of primitive type elements.


High Level Instructions
-----------------------

1. Open the SimpleCharArray class of the DemoProject project in the
   demos/mod05_arrays/exercise1 directory.

2. Explain the createArray method that creates an char[] array.

3. Compile the SimpleCharArray class.

4. Run the SimpleCharArray program.
