Overview
--------

The purpose of this demo is to show students how to declare, create and
manipulate an array of reference type elements.


High Level Instructions
-----------------------

1. Open the Student class of the DemoProject project in the
   demos/mod05_arrays/exercise2 directory.

2. Explain the Course[] type instance variable courses.

3. Explain how the courses instance variable is initialized in the constructor.

4. Explain the addCourse method.

5. Open the TestStudent class.

6. Compile the TestStudent class.

7. Run the TestStudent program.
