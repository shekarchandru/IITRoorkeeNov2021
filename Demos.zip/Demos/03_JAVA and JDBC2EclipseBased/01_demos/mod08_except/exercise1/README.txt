Overview
--------

The purpose of this demo is to show students how to create a custom Exception
class, and use it in a Java program.


High Level Instructions
-----------------------

1. Open the Employee class of the DemoProject project in the
   demos/mod08_excep/exercise1 directory.

2. Explain the promoteToCEO method. This method checkes the current role of
   the Employee, and the promotion succeeds only if the current role is
   Manager. Otherwise, a CustomException is thrown.

3. Open the CustomException class and explain how to create a new type of
   Exception.

4. Open the TestEmployee class and explains the try/catch/finally block.

5. Compile the TestEmployee class.

6. Run the TestEmployee program.
