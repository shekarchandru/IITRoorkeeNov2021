public class CustomException extends java.lang.Exception {
    public CustomException() {
    }
    
    public CustomException(String msg) {
        super(msg);
    }
}
