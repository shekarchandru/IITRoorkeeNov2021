Overview
--------

The purpose of this demo is to show students how to add a menu and other GUI
components to a AWT application.


High Level Instructions
-----------------------

1. Open the SampleMenu class of the DemoProject project in the
   demos/mod12_guiapps/exercise1 directory.

2. Explain How to add menus to a GUI application.

3. Compile the SampleMenu class.

4. Run the SampleMenu program.

5. Stop the SampleMenu Process.

   To achieve this, expand the processes node in the Runtime tab, and stop
   the process.

6. You can also use the TestColor class to demonstrate how to manipulate
   colors in a GUI application.