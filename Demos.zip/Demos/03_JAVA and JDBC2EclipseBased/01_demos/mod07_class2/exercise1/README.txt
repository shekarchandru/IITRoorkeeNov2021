Overview
--------

The purpose of this demo is to show students how to declare static members
in a class, including both member variables and methods.


High Level Instructions
-----------------------

1. Open the Count class of the DemoProject project in the
   demos/mod07_class2/exercise1 directory.

2. Explain the static member variable counter and the static method
   getTotalCount.

3. Open the TestCounter class and explain how the static method
   getTotalCount of the Count class is called.

4. Compile the TestCounter class.

5. Run the TestCounter program.