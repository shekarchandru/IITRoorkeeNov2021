public class Manager implements Role{
    public String getRoleName() {
        return "Manager";
    }
    
    public String getResponsibility() {
        return "Manages a department";
    }
}
