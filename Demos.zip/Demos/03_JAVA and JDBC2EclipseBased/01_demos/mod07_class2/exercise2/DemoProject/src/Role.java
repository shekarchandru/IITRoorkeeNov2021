public interface Role {
    public String getRoleName();
    public String getResponsibility();
}
