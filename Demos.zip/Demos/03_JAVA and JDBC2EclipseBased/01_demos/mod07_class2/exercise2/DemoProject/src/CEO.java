public class CEO implements Role {
    public String getRoleName() {
        return "CEO";
    }
    
    public String getResponsibility() {
        return "Manages a company";
    }
}
