Overview
--------

The purpose of this demo is to show students how to define an interface, and
create a class that implements this interface.


High Level Instructions
-----------------------

1. Open the Role interface of the DemoProject project in the
   demos/mod07_class2/exercise2 directory.

2. Explain the syntax of the Role interface.

3. Open the Manager and CEO classes to explain how a Java class implements
   an interface.

4. Open the Employee class to explain the role type instance variable.

   This Employee class uses composition, instead of inheritance to establish
   the relationship between Employee and Manager.

5. Compile the TestEmployee class.

6. Run the TestEmployee program.
