Overview
--------

The purpose of this demo is to show students how to create a TCP based Java
client, and use user-provided system properties to drive a Java program.


Resources
---------

A SolutionProject is provided with this demo. You can run this demo
immediately.

High Level Instructions
-----------------------

1. Open the SimpleServer class of the DemoProject in the demos/mod15_network
   directory.

2. Demonstrate the TCP server socket API used in the SimpleServer class.

3. Open the SimpleClient class.

4. Explain TCP socket API used in the SimpleClient class.

5. Compile the SimeleServer class.

6. Run the SimpleServer program.

7. Compile the SimpleClient class.

8. Set the following JVM options:

   Server=127.0.0.1
   Port=5432

   To achieve this, you can right click the DemoProject, select Properties from
   the popup menu, click Run in the Properties Window, and add the above
   properties to the JVM options using the following format:

   -DServer=127.0.0.1
   -DPort=5432

9. Run the SimpleClient program.

10. Stop the SimpleClient process.