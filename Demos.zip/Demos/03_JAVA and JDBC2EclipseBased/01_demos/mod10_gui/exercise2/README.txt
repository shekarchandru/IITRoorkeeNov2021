Overview
--------

The purpose of this demo is to show students how to create a Java class that
uses the AWT API to create a simple GUI front end.


High Level Instructions
-----------------------

1. Open the ComplexLayoutExample class of the DemoProject project in the
   demos/mod10_gui/exercise2 directory.

2. Explain How to use panels to achieve complicated GUi layout.

3. Compile the ComplexLayoutExample class.

4. Run the ComplexLayoutExample program.

5. Stop the ComplexLayoutExample Process.

   To achieve this, expand the processes node in the Runtime tab, and stop
   the process.

