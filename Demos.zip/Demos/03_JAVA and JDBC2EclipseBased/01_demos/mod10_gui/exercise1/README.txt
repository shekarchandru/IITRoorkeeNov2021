Overview
--------

The purpose of this demo is to show students how to create a Java class that
uses the AWT API to create a simple GUI front end.


High Level Instructions
-----------------------

1. Open the FlowExample class of the DemoProject project in the
   demos/mod10_gui/exercise1 directory.

2. Explain the functionality of the FlowLayout.

3. Compile the FlowExample class.

4. Run the FlowExample program.

5. Stop the FlowExample Process.

   To achieve this, expand the processes node in the Runtime tab, and stop
   the process.
