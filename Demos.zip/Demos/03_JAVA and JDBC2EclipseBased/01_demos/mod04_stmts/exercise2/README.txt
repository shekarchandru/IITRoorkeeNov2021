Overview
--------

The purpose of this demo is to show students how to use conditional statements
in a method.


High Level Instructions
-----------------------

1. Open the DemoProject project in the demos/mod04_stmts/exercise2 directory.

2. Open the TestInitBeforeUse class.

3. Compile the TestInitBeforeUse class, and explain the compilation error.

4. Correct the compilation error by assigning an initial value to variable y.

5. Compile the TestInitBeforeUse class.

6. Run the TestInitBeforeUse program.
