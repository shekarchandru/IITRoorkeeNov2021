Overview
--------

The purpose of this demo is to show students how to write a nested loop.


High Level Instructions
-----------------------

1. Open the Loops class of the DemoProject project in the
   demos/mod04_stmts/exercise3 directory.

2. Explain the foo loop nested in the while loop.

   This example also uses the labeled continue and labeled break statements.

3. Compile the Loops class.

4. Run the Loops program.