Overview
--------

The purpose of this demo is to show students how to write a simple loop.


High Level Instructions
-----------------------

1. Open the DemoProject project in the demos/mod04_stmts/exercise1 directory.

2. Open the TestWhileLoops class, and explain the loop structures used in the
   class.

3. Compile the TestWhileLoops class.

4. Run the TestWhileLoops program.
