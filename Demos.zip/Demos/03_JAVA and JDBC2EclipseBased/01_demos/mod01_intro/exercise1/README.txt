Overview
--------

The purpose of this demo is to show students how to open an existing Java
Application Project, open a Java file in the project, compile the Java class
and run the Java program.


Resource
--------

The GreetingProject is provided with this demo, and it should have been mounted
to the NetBeans IDE on the instructor's workstation. If it was not mounted yet,
then you should open the project first.


Instructions
------------

1. Start the NetBeand IDE

2. Open the TestGreeting and Greeting classes.

3. Compile the TestGreeting class.

4. Run the TestGreeting program.