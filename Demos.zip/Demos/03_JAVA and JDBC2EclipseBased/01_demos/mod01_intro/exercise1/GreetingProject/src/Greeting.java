//
// The Greeting class declaration.
//
 public class Greeting {
    public void greet() {
       System.out.println("hi");
    }
  }
