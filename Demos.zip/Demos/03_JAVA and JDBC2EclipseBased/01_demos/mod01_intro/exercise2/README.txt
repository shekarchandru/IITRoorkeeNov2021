Overview
--------

The purpose of this demo is to show students how to create a new Java
Application Project, copy a file (Java class) to the source package of the
project, create a Java class in the project, compile the Java class and run
the Java program.

Resources
---------

A SolutionProject project is provided in the demos/mod01_intro/exercise2
directory.

Instructions
------------

1. Create a new Java Application Project in the demos/mod01_intro/exercise2
directory with the following characteristics:

Category: General
Projects: Java Application
Project Name: DemoProject
Uncheck Set as Main Project and Create Main Class

2. Copy the Greeting class from the examples/mod01_intro directory to the
   source package of the DemoProject Java Application Project.

3. Create a Test class in the source package of the DemoProject project.

4. Add a main method in the Test class.

5. In the main method, create a Greeting object, and call the greet method.

6. Compile the Test class.

5. Run the Test Program.

