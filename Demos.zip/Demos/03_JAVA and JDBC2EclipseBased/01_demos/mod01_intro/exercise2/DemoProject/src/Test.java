/*
 * Test.java
 *
 * Created on November 26, 2005, 1:21 AM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

/**
 *
 * @author student
 */
public class Test {
    
    /** Creates a new instance of Test */
    public Test() {
    }
    
    public static void main(String[] args) {
        Greeting greeting = new Greeting();
        greeting.greet();
    }
}
