Overview
--------

The purpose of this demo is to show students how to define an reference type
instance variable in a Java class, and manipulate the object referenced by
this variable.


High Level Instructions
-----------------------

1. Open the DemoProject in the demos/mod03_types/exercise2 directory.

2. Open the Student class and explain the Address type instance variable
   address.

3. Compile the TestStudent class.

4. Run the TestStudent program.

