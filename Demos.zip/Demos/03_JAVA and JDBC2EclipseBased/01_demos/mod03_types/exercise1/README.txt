Overview
--------

The purpose of this demo is to show students the effects of reference type
variable assignment.


High Level Instructions
-----------------------

1. Open the DemoProject in the demos/mod03_types/exercise1 directory.

2. Open the TestMyDate class.

3. Explain the difference of the second and third assignment statements.

4. Compile the TestMyDate class.

5. Run the TestMyDate program and explain the results.

