Overview
--------

The purpose of this demo is to show students how to create a Java class that
represents a separate thread of control flow.


High Level Instructions
-----------------------

1. Open the Producer class of the DemoProject in the demos/mod13_threads
   directory.

2. Explains how the Producer class can be used to create a new thread.

   You can also use the Consumer class to demonstrate the same concept.

3. Open the SyncStack class to demonstrate how to create a thread-safe
   class.

4. Open the SyncTest class to demonstrate how to create new threads and
   start them.

5. Compile the SyncTest class.

6. Run the SyncTest program.

7. Because the producer and consumer threads run in their infinity loops,
   you may want to terminate the SyncTest process.
