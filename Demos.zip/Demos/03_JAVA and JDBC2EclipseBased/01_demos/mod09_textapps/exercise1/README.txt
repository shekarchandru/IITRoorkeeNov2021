Overview
--------

The purpose of this demo is to show students how to prepare the directory
structure of the Java Application Project, and write a program to read data
from a file. This demo also shows how to run a program with user provided
command line arguments.

Resources
---------

A Solution project SolutionProject is provided in the
demos/mod09_textapps/exercise1 project.

High Level Instructions
-----------------------

1. Open the DemoProject project in the demos/mod09_textapps/exercise1
   directory.

2. Create a data directory in the DemoProject.

3. Copy the romeo_and_julie.txt file from the demos/mod09_textapps/exercise1
   directory to the data directory.

   The easiest way to copy a file from outside a project is to add the source
   directory to the favorites of the NetBeans IDE, and then copy the file.

4. Open the ReadFile class.

5. Explain the statement that creates a File object.

   The constructor argument passed is args[0]. This value will be provided
   as a command line argument.

6. Explain how the ReadFile class is implemented to read from a file.

7. Set the argument of the DemoProject project to data/romeo_and_juliet.txt,
   aand set the main class to ReadFile.

   To do this, right click the DemoProject, select Properties from the popup
   menu, click Run in the Project Properties window, and set the argument.

8. Build and run the project.