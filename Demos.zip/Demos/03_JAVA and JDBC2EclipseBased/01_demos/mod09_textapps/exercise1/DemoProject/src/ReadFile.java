import java.io.*;
public class ReadFile {
    public static void main(String [] args) {
        File file = new File(args[0]);        
        try {
            BufferedReader in = new BufferedReader(new FileReader(file));
            String s = null;
            while ((s = in.readLine()) != null) {
                System.out.println(s);
            }
            in.close();
        } catch (FileNotFoundException e1) {
            System.err.println("File not found: " + file);
        } catch (IOException e2) {
            e2.printStackTrace();
        }
    }
}
