Overview
--------

The purpose of this demo is to show students how to use the Collection API and
generics in a Java program.


High Level Instructions
-----------------------

1. Open the Student class of the DemoProject project in the
   demos/mod09_textapps/exercise2 directory.

2. Explain the definition of the instance variable courses, which has a type
   of List<Course>.

3. Explain the initialization of the instance variable courses in the
   constructor.

4. Explain the addCourse and printCourses methods.

5. Compile the TestStudent class.

6. Run the TestStudent program.
