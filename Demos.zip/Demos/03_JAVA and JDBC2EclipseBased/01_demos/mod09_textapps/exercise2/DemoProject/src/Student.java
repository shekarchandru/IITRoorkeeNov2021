import java.util.ArrayList;
import java.util.List;
public class Student {
    private int studentID;
    private String firstName;
    private String lastName;
    private Address address;
    private List<Course> courses;
    
    public Student(int id, String fn, String ln, Address addr) {
        studentID = id;
        firstName = fn;
        lastName = ln;
        address = addr;
        courses = new ArrayList<Course>();
    }
    
    public int getStudentID() {
        return studentID;
    }
    
    public String getFirstName() {
        return firstName;
    }
    
    public String getLastName() {
        return lastName;
    }
    
    public Address getAddress() {
        return address;
    }
    
    public void addCourse(Course course) {
        courses.add(course);
    }
    
    public String toString() {
        return firstName + " " + lastName + "\n" + address.toString();
    }
    
    public void printCourses() {
        for(int i = 0; i < courses.size(); i++) {
            System.out.println(courses.get(i));
        }
    }
}
