Overview
--------

The purpose of this demo is to show students how to declare, create and
manipulate an one-dimension array of reference type elements. The element
type is declared as having the super class type, while the element is allowed
to reference an object created from a subclass.


High Level Instructions
-----------------------

1. Open the TestStudent class of the DemoProject project in the
   demos/mod06_class1/exercise2 directory.

2. Explain the declaration and initialization of the Student[] type variable
   students.

3. Exlain the following two assignment statements.

4. Compile the TestStudent class.

5. Run the TestStudent program.
