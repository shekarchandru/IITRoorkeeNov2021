/*
 * NewClass.java
 *
 * Created on October 18, 2006, 2:26 PM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

/**
 */

  
 public class NewClass
{

public static void main(String args[])
 {
String name = "Neeru";
int age = 10;
float salary = 123456.56;
System.out.println("Name: " + name + "Age: " + age + "Salary: " + salary);
 } 
}

