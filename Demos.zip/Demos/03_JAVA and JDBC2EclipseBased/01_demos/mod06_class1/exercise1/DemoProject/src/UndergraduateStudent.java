public class UndergraduateStudent extends Student {
    public UndergraduateStudent(int id, String fn, String ln) {
        super(id, fn, ln);
    }    
}
