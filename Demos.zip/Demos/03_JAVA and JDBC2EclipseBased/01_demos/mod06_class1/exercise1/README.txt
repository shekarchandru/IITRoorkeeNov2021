Overview
--------

The purpose of this demo is to show students how to define a subclass based on
an existing super class, and make necessary modifications to the super class,
such as changing the access modifiers to instance variables.


High Level Instructions
-----------------------

1. Open the GraduateStudent class of the DemoProject project in the
   demos/mod06_class1/exercise1 directory.

2. Explain the extends keyword used in the GraduateStudent class definition.

3. Explain the constructor of the GraduateStudent class.

4. Open the Student class, and explain the protected instance variables
   firstName and lastName.

5. Explain the toString method of the GraduateStudent class.

6. Compile the TestStudent class.

7. Run the TestStudent program.
