public class Test {
    
    /** Creates a new instance of Test */
    public Test() {
    }
    
    public static void main(String[] args) {
        Greeting greeting = new Greeting();
        greeting.message = "Hi, there";
        greeting.greet();
    }
}
