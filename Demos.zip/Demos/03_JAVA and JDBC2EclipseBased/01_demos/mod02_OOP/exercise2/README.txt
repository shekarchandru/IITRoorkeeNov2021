Overview
--------

The purpose of this demo is to show students how to delete a Java class in 
the project, create a Java class in the project, compile the Java class and
run the Java program.


Instructions
------------

1. Open the DemoProject project in the demos/mod02_OOP/exercise2 directory.

2. Delete the Greeting class.

3. Create the Greeting Java class with the following characteristics:

   Project: DemoProject
   Class Name: Greeting
   Location: Source Packages

4. Add a public String type instance variable message to the Greeting class.

5. Add a constructor with a String type argument that initializes the message
   instance variable.

6. Add a greet method to the Greeting class. This method should be public, and
   it should return a void.

7. In the greet method of the Greeting class, print the value of the message
   instance variable.

8. Modify the main method of Test class to create a Greeting object, assign
   a value to the message instance variable of the object, and call the greet
   method.

9. Compile the Test class.

10. Run the Test Program.

