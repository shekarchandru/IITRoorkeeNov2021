import zoo.Dog;
public class Test {
    public static void main(String[] args) {
        Dog d = new Dog();
        d.setWeight(30);
        System.out.println("The dog has a weight of " + d.getWeight());
    }
}
