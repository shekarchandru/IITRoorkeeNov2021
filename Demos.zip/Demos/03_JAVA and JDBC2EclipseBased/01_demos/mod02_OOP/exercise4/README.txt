Overview
--------

The purpose of this demo is to show students how to create a source package
in a project, and move a Java class from one package to another without
refactoring the class.


High Level Instructions
-----------------------

1. Open the DemoProject project in the demos/mod02_OOP/exercise4 directory.

2. Create a new Java Package called zoo.

3. Move the Dog class from the default package to the zoo package.

   The NetBeans IDE allows you to automatically refactor the Java classes to
   modify necessary package and import statements.

4. Compile the Java class.

5. Run the Program.

