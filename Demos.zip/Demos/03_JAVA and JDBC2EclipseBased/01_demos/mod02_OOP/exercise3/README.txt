Overview
--------

The purpose of this demo is to show students how to add appropriate access
control modifiers (public/private) to instance variables, define Java methods
in the Java class, and call these methods from another class.


High Level Instructions
-----------------------

1. Open the DemoProject project in the demos/mod02_OOP/exercise3 directory.

2. Add a private modifier to the weight instance variable.

3. Compile the Test class.

4. Run the Test Program.


