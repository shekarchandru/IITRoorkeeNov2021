public class Dog {
    int weight;
    
    public Dog() {
        weight = 42;
    }
    
    public int getWeight() {
        return weight;
    }
    public void setWeight(int newWeight) {
        weight = newWeight;
    }
}
