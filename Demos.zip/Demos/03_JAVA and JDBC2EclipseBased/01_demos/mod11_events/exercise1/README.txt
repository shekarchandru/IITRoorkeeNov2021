Overview
--------

The purpose of this demo is to show students how to use the Event handling
API to handle simple GUI events.


High Level Instructions
-----------------------

1. Open the ButtonHandler class of the DemoProject project in the
   demos/mod11_events/exercise1 directory.

2. Explain How to develop a class that implements an ActionListener.

3. Open the TestButton class.

4. Explain the meaning of the first line in the launchFrame method.

5. Compile the TestButton class.

6. Run the TestButton program.

7. Stop the TestButton Process.

   To achieve this, expand the processes node in the Runtime tab, and stop
   the process.

