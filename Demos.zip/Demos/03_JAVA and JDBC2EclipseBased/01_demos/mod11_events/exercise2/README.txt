Overview
--------

The purpose of this demo is to show students how to use the Event handling
API to handle simple GUI events.


High Level Instructions
-----------------------

1. Open the TwoListener class of the DemoProject project in the
   demos/mod11_events/exercise2 directory.

2. Explain How to develop a class that implements multiple event listeners.

3. Compile the TwoListener class.

4. Run the TwoListener program.

5. Stop the TwoListener Process.

   To achieve this, expand the processes node in the Runtime tab, and stop
   the process.

