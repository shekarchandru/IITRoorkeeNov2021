public class Test1 {
  public static void main(String[] args) {
    System.out.println("What's wrong with this program?");
  }
}
class TestAnother1 {
  public static void main(String[] args) {
    System.out.println("What's wrong with this program?");
  }
}
