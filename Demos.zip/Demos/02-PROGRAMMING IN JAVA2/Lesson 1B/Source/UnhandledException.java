class UnhandledException 
{
	public  atic void main(String args[])
 	{
		int num1=0, num2=5;
		int num3=num2/num1;
		System.out.println ("The num3 = " + num3);
	}
}