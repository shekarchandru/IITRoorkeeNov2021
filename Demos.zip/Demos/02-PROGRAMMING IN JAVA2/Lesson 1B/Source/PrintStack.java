class PrintStack
{
	public static void main(String a s[]) 
	{
		int Num1= 30 , Num2 = 0;
   		try
		{
    			 int Num3=Num1/Num2;
   		}
		 catch(ArithmeticException obj) 
     		{
			obj.printStackTrace();
		}
   	}
}


