interface TBooks 
{
//Defining constants in an interface.
final int cd =10;
final int book =5;
}� 

