class Book //Declaration of the Superclass
{
//Declaring the variables.
int price = 50;
int pages = 500;
�Defining the method.
public void show() //declaring the show() method
	{
		System.out.println(" ");
		System.out.println("\t Books Information");
		System.out.println("\t Book Price: " + price);
		System.out.println("\t Number of pages: " + pages);
		System.out.println(" ");
	 }
}
