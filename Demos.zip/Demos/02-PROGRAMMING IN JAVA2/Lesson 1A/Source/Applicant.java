

class Applicant 
{
		// Declaring data members
� tring applicantID;
	String applicantName;
	String applicantAddress = "12, ParkStreet";
	String applicantPosition = "Manager";
		//Defining the method.
public void displayDetails()
	{
		//Code for displaying the values of data members.
	System.out.println("Applicant ID=" +applicantID);
	System.out.println("Applicant Name=" +applicantName);
	System.out.println("Applicant Address=" +applicantAddress);
System.out.println("Applicant Position=" +applicantPosition);
} 
}
