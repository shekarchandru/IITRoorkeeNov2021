class Dcd implements TBooks
{
  void display()
  {
   System.out.println(" ");
   System.out.println("\t  e number of purchased CD's are :" + cd);
   System.out.println(" ");
  }
}

