interface Bank
{
public void bankDeposit();
}
