interface FinancialInstitute
{
public void securityDeposit();
}
