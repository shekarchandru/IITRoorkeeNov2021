import BankDet.SamplePack;
public class Bank
{
	public static void �in(String args[])
	{
	//Creating instance of the class 'SamplePack'.
	SamplePack myobj=new SamplePack("John Smith",1001,1002);	myobj.display();
}
}
