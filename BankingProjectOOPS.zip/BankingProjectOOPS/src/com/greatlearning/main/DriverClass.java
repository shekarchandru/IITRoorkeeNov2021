package com.greatlearning.main;

import java.util.Scanner;

import com.greatlearning.model.Customer;
import com.greatlearning.service.Banking;

public class DriverClass {

	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Customer customer = new Customer("ICICI1234","password1234");
		Banking banking = new Banking();
		String bankActNo;
		String pswd;
		Scanner scan1 = new Scanner(System.in);
		System.out.println("Enter the Bank Account NO...");
		bankActNo = scan1.next();
		System.out.println("Enter the Password...");
		pswd = scan1.next();
		int choice=0;
		if (bankActNo.equals(customer.getBankAccountNo()) && pswd.equals(customer.getPassword()))
		{
			System.out.println("-------------------Welcome to ICICI Bank...---------------------");
			do
			{
				System.out.println("------------------------MAIN MENU-----------------------------");
				System.out.println("1. Deposit");
				System.out.println("2. Withdrawal");
				System.out.println("3. Transfer");
				System.out.println("0. Exit");
				System.out.println("Enter Your Choice...");
				choice = scan1.nextInt();
				switch(choice)
				{
					case 0:
					{
						choice = 0;
						System.out.println("Exited Successfully...");
						break;
					}
					case 1:
					{
						banking.deposit();
						break;
					}
					case 2:
					{
						banking.withdrawAmt();
						break;
					}
					case 3:
					{
						banking.transferAmt();
						break;
					}
				}
				
				System.out.println("-----------------------------------------------------");
			}while(choice != 0);
		}
		else
		{
			System.out.println("Sorry Invalid Credentials...");
		}
		

	}

}
