package com.greatlearning.service;

import java.util.Random;

public class OTPGenerator {

	 Random randnum;
	public int generateOTP()
	{
		int randomPin = ((int)Math.random()+(int)Math.random() * 9000)+1000;
		return randomPin;
	}
	/*
	 * 0.5 * 9000 4500.0
	 * 0.5 * 10000 5000.0
	 */
	public int generateNewOTP(int x)
	{
		

		  	        randnum = new Random();
		        randnum.setSeed(123456789);
		        return randnum.nextInt(x);
		   
	}
}
