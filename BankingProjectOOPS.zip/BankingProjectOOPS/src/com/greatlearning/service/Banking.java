package com.greatlearning.service;

import java.util.Scanner;

public class Banking {

	Scanner scan1 = new Scanner(System.in);
	OTPGenerator otpGenerator = new OTPGenerator();
	int bankBalance = 1000;
	
	public void deposit()
	{
		int amount;
		System.out.println("Enter teh amount you wish to deposit...");
		amount = scan1.nextInt();
		if(amount > 0)
		{
			System.out.println(" AMount "+amount+" Deposited successfully...");
			bankBalance = bankBalance + amount;
			System.out.println("The Balance amount is "+bankBalance);
		}
		else
		{
			System.out.println("Enter Valid amount...");
		}
		
		
	}
	public void withdrawAmt()
	{
		int amount;
		System.out.println("Enter the amount you wish to withdraw...");
		amount = scan1.nextInt();
		if(bankBalance - amount >= 0)
		{
			System.out.println("Amount "+amount+" Withdrawal successful...");
			bankBalance = bankBalance - amount;
			System.out.println("The remaining balance is "+bankBalance);
		}
		else
		{
			System.out.println("Insufficient Funds...");
		}
		
	}
	public void transferAmt()
	{
		int amount;
		int otp;
		int otpGenerated;
		int bankAccountNo;
		System.out.println("Enter the OTP...");
		//otpGenerated = otpGenerator.generateOTP();
		otpGenerated = otpGenerator.generateNewOTP(240);
		System.out.println("OTP is "+otpGenerated);
		otp = scan1.nextInt();
		if( otp == otpGenerated)
		{
			System.out.println("OTP Verification successful...");
			System.out.println("Enter the act number to which you wish to transfer amount");
			bankAccountNo = scan1.nextInt();
			System.out.println("Enter the Amount you wish to transfer...");
			amount = scan1.nextInt();
			if(bankBalance -amount >= 0)
			{
				System.out.println("Amount "+amount+" Transferred to account "+bankAccountNo+" Successfully...");
			}
			else
			{
				System.out.println("Insufficient balance");
			}
		}
		else
		{
			System.out.println("Sorry Invalid OTP...");
			
		}
	}
}
