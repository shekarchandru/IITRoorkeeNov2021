package com.greatlearning.LibraryManagementSecure;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LibraryManagementSecureApplication {

	public static void main(String[] args) {
		SpringApplication.run(LibraryManagementSecureApplication.class, args);
	}

}
