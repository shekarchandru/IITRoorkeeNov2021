package com.greatlearning.LibraryManagementSecure;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LibraryManagementSecureApplicationTests {

	@Test
	void contextLoads() {
	}

}
